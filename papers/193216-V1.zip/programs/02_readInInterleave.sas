/***************************************************
*This program reads in the LEHD 2021 interleave file because
*Stata's import sas command cannot read it.
*Created by: Dani Sandler
*Created on: April 27, 2020
*Modifications:
  5/27/20 - DHS - Added merge to SED data, since Stata still can't read 
		directly exported interleave data (*fingers crossed*)
		Probably better not to be saving giant files anyhow
 5/28/20 - DHS - Added where missingpik~=1 to SED sort
 1/24/23 - DHS - Changed to use 2021 Interleave
***************************************************/



proc contents data=inter.phf_interleave_b;
run;

proc import out=mydata.sed_2001_2017 
datafile="SED_2001_2017_piks.dta"
replace;
run;

proc sort data=mydata.sed_2001_2017
    out=mydata.sed_2001_2017;
    by pik;
run;

proc sort data=inter.phf_interleave_b
    out=mydata.phf_interleave_b;
    by pik;
run;

data mydata.phf_sed_merge;
  merge inter.phf_interleave_b (in=phf)
	mydata.sed_2001_2017 (in=sed);
	by pik;
	if sed=1;
run;

proc export data=mydata.phf_sed_merge
  outfile="phf_sed_merge.dta"
  dbms=stata replace;
run;
