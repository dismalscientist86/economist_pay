/*********************************
Program name: 01g_SED_phf_merge.do
Purpose: To merge the SED data and the PHF file that has 
already been restricted to just cover observations observed in the 
SED. Then create some summary stats of LEHD employment of 
doctoral recipients
Created by: Dani Sandler
Created on: October 28, 2020
Modifications: 10/28/20 - DHS - Modified from 02b_merge_phf_econ.do
		4/6/21 - DHS - Changed file qtr_xwalk to match phdfy to final quarter of calendar year
		    (Instead of second quarter) to better line up with annual IRS earnings
		9/20/21 - DHS - Add economist variable to keep statement
**********************************/

*Master setup program
do 00_master_SED_LEHD.do

log using $programs/logs/03_SED_phf_merge${c_date}.log, replace

insheet using ${mydata}/qtr_xwalk.csv, clear

drop if missing(phdfy)
keep lehdquarter phdfy

tempfile lehdqtr
save `lehdqtr', replace

use ${mydata}/SED_2001_2017.dta, clear

tab phdfy, m

merge m:1 phdfy using `lehdqtr'

drop if _merge!=3
drop _merge

*Drop missing piks
drop if missing(pik)

duplicates report pik
*Drop duplicates, favoring economics degree, if there is one
gsort pik -economist
drop if pik==pik[_n-1]


merge 1:m pik using ${mydata}/phf_sed_merge.dta

keep if _merge==3
drop _merge

summ

*Save the uncollapsed data
save ${mydata}/SED_phf.dta, replace


*Create a SEIN-Year-Quarter file from SED-PHF matched data for matching to ECF
preserve
keep sein first_acc

rename first_acc qtime

/*Could be duplicates from multiple people starting at the SEIN in same quarter*/

gduplicates report

gduplicates drop

drop if missing(sein)
drop if missing(qtime)

saveold ${mydata}/SED_sein.dta, replace

restore



