/*************************************
*Program Name: readInSED.do
*Purpose: To read in the SED data and run some basic tabulations
	on the data contents
*Created by: Dani Sandler
*Created on: April 17, 2020
*Changes: 7/8/20 - DHS - Change import to use full survey data
	  7/13/20 - DHS - Added tab of race/ethnicity and institution & employer tabs within log
	  11/4/20 - DHS - Edited for changed SED Paths
	  9/20/21 - DHS - Added definition of economists
*************************************/
*Master setup program
do 00_master_SED_LEHD.do

log using $programs/logs/01_SED_Setup${c_date}.log, replace

*Import survey variables 
import sas using ${SEDdata}/sed_2000_2017.sas7bdat, clear case(lower)
summ 

tempfile SED
save `SED', replace

import sas using ${SEDpiks}/nsf_ncses_sed_2001_2017_rsch.sas7bdat, clear case(lower)
summ
keep dqb_source_id drf_id

gduplicates report

gduplicates report drf_id

tempfile SED_xwalk
save `SED_xwalk', replace

*Import PIK file
import sas using ${SEDpiks}/nsf_ncses_sed_2001_2017_pvs.sas7bdat, clear case(lower)
summ

tempfile PIK
save `PIK', replace

*Start with the SED crosswalk, link to PIKs, then link that to survey data.
*We do this because there are duplicate DRF_IDs in the crosswalk, which have different
*DQB_SOURCE_ID variables. Without doing it in this order, we either might miss PIK matches
*Or introduce duplicates into our survey data

use `SED_xwalk', clear
merge 1:1 dqb_source_id using `PIK'
drop _merge

gduplicates report

gduplicates report drf_id
gduplicates tag drf_id, gen(dup1)

gduplicates report drf_id pik
gduplicates tag drf_id pik, gen(dup2)

tab pik if dup1!=dup2, m
drop if missing(pik) & dup1!=dup2
drop dup1 dup2

*All other duplicates we will force drop (since have identical PIKs)
gduplicates drop drf_id, force

*Now merge to survey data
merge 1:1 drf_id using `SED'
gen no_xwalk_match=(_merge!=3)
drop _merge 
*Note: We have PIKs for 2001-2017, but SED survey data for 2000-2017. No match for the year 2000 observations


keep if no_xwalk_match==0
drop no_xwalk_match

destring sex, replace
destring inp_stdecd, replace
estpost summarize *

*Define Economists.
gen economist=((phdfield==667|phdfield==0|phdfield==3|phdfield==665|phdfield==668) & (doccode=="01" | doccode=="02"))

*Encode pdemploy
replace pdemploy="" if pdemploy=="98"
encode pdemploy, gen(pdemploy2)

save ${mydata}/SED_2001_2017.dta, replace
gen missingpik=missing(pik) 
keep if missingpik==0

gduplicates report pik

*How many of these duplicate PIKs are people w/ multiple Ph.Ds
gduplicates tag pik, gen(pikdup)

tab phdcount if pikdup>0, m

destring phdcount, force replace
bysort pik: gegen maxphdcount=max(phdcount)

tab maxphdcount if pikdup>0, m

keep pik 
gduplicates drop

saveold ${mydata}/SED_2001_2017_piks.dta, replace 
export delimited using ${mydata}/SED_2001_2017_piks.csv, replace //CSV for SAS import

