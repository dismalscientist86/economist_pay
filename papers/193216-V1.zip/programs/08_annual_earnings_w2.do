/*************************
Program name: 04_annual_earnings.do
Created by: Dani Sandler
Created on: February 2, 2021
Purpose: Create an annual earnings series, using fiscal/academic year earnings 
  (earnings year starts in Q4 of t-1)
Modifications: 2/25/21 - DHS - Added a floor of minimum wage full time equivalent earnings to 
			  be included in earnings average
			     - Excluded NHPI from graph by race. Weird outlier made it hard to read
	      3/3/20 - Changed data to ICF merge. 
			Harmonized ICF & SED race. Changed graphs to used harmonized values.
	      6/29/2021 - Added Institution Rank measures
	      7/14/2021 - Keep full NAICS code to break out more detailed industries
		  12/14/2022 - Add employer RePEc rankings
***************************/
 
*Master setup program
do 00_master_SED_LEHD.do

log using $programs/logs/07_annual_earnings_w2${c_date}.log, replace


use ${mydata}/SED_w2_match.dta, clear
destring wage_tip, force replace


keep wage_tip year sex phdfy agedoc race2 race_harm race_agg* us_born us_citiz pik ein economist phdinst phdcarn pdemploy2 phdfield
unique pik year ein
keep if year>phdfy
gen years_since=year-phdfy

destring phdinst, replace

*First Winsorize before aggregating
gen pos_earn=wage_tip if wage_tip!=0
summ wage_tip, d
bysort year: gegen winsor=pctile(wage_tip),p(99)
replace wage_tip=winsor if wage_tip>winsor
drop pos_earn winsor

*And use real (2015) dollars
merge m:1 year using ${mydata}/cpi_6717.dta
keep if _merge==3
drop _merge
replace wage_tip=wage_tip*237.017/cpi

tempfile earnings
save `earnings'

*Bring in RePEc rankings data
import delimited "$mydata/IPEDS_EIN_Xwalk/iped_sein_xwalk.csv", clear 
rename unitid ipeds_num 

*Drop sein and deduplicate
drop sein
duplicates drop

rename repec_rank_20221216 employer_repec_rank
tab employer_repec_rank if ein==-1, m
drop if ein==-1
duplicates tag ein, gen(dup)
tab employer_repec_rank if dup>0, m
drop dup

*Always keep the lower value (higher ranked) of repec_rank for schools with more than one
sort ein employer_repec_rank
drop if ein==ein[_n-1]
unique ein
tostring ein, replace
gen ein_length=length(ein)
tab ein_length
replace ein="00"+ein if ein_length==7
replace ein="0"+ein if ein_length==8
drop ein_length

tempfile repec_ein
save `repec_ein'

use `earnings', clear
merge m:1 ein using `repec_ein'
*Schools in the top 100 that don't match by EIN
tab employer_repec_rank if _merge==2
tab instnm if _merge==2 & employer_repec_rank!=.
drop if _merge==2 & employer_repec_rank==.
drop _merge

save ${mydata}/SED_w2_earnings2020.dta, replace

