/**************************************
*Program name: 01j_SED_w2_match.do
*Purpose: To match SED data to the IRS W2 data to 
identify employers not in LEHD or OPM
*Created by: Dani Sandler
*Created on: 1/26/2021
*Modifications: 1/26/21 - DHS - Modified from 02e_economist_w2_match.do
*               1/31/23 - DHS - Added years 2018-2021
**************************************/

do 00_master_SED_LEHD.do

log using $programs/logs/04_SED_ICF_merge${c_date}.log, replace


use ${mydata}/SED_2001_2017_piks.dta, clear

unique pik 

keep pik

duplicates drop

tempfile SED_piks
save `SED_piks'

tempfile SEDw2

forvalues i=2005/2020{

import sas using $irsw2/`i'/iw2ty`i'_dups_flagged.sas7bdat, case(lower) clear

*Remove duplicates according to recommedations in the Readme for the W2 data
keep if inlist(dup_flag,"N1","AX","X1","D1","FX","TX")

summ

tempfile dups_flagged_`i'
save `dups_flagged_`i'', replace

import sas using $irsw2/`i'/iw2ty`i'_summaryrecs.sas7bdat, case(lower) clear

*Remove duplicates according to recommedations in the Readme for the W2 data
keep if inlist(dup_flag,"N1","AX","X1","D1","FX","TX")

append using `dups_flagged_`i''

merge m:1 pik using `SED_piks'

keep if _merge==3
drop _merge

display "`i'"
unique pik

if `i'>2005{
  append using `SEDw2'
}

save `SEDw2', replace
}

use `SEDw2', clear

summ

tab year

*Merge the survey data back in
use ${mydata}/icf_phf_sed_merge.dta, clear
drop if missing(pik)

*Rename Ph.D. quarter more sensibly
rename lehdquarter phdqtr

destring phdinst, replace

*Use gcollapse to remove duplicates
gcollapse (firstnm) phdfy agedoc sex race_harm race_agg* race2 white black hispanic asian aian nhpi twoplus us_born us_citiz phdqtr economist phdinst phdcarn pdemploy2 phdfield, by(pik) labelformat(#sourcelabel#) 

merge 1:m pik using `SEDw2'

keep if _merge==3
drop _merge
 

save ${mydata}/SED_w2_match.dta, replace


