/***************************************************************************/
/*Program: run_all_economists.sas                                          */
/*Description: Runs code in sequence to recreate input data for "Early     */
/*             Career Paths of Economists Inside and Outside of Academia"  */
/*             and creates tables and figures for the paper                */
/***************************************************************************/

x cd /programs;

/*Dani's programs constructing the analysis data set are a mix of Stata and SAS code*/

x stata -b do 01_readInSED.do;

%macro job;
  %include "/programs/02_readInInterleave.sas" ;
%mend;
%job;

x stata -b do 03_SED_phf_merge.do;
x stata -b do 04_SED_ICF_merge.do;

%macro job2;
  %include "/programs/05_SED_ecf_match.sas" ;
%mend;
%job2;

x stata -b do 06_SED_w2_match.do;
x stata -b do 07_annual_earnings_lehd.do;
x stata -b do 08_annual_earnings_w2.do;
x stata -b do 09_annual_earnings_combined_redacted.do;

/*Run Erika's programs that add additional variables needed in downstream analysis*/

%macro job3;
  %include "/programs/mcent002/00.00.mk_econ_annearn.sas" ;
  %include "/programs/mcent002/00.01.add_ein_naics.sas" ;
  %include "/programs/mcent002/00.02.add_ein_naics.sas" ;
  %include "/programs/mcent002/00.03.add_phdinst.sas" ;
  %include "/programs/mcent002/00.04.add_ranks.sas" ;
%mend;
%job3;

/*Run programs that create tables and figures*/
/*First create the output directories for releasable output and for supplemental files for disclosure*/

x mkdir /programs/mcent002/analysis/CBDRB-FY2022-CES005-001/output;
x mkdir /programs/mcent002/analysis/CBDRB-FY2022-CES005-001/supplement;
x mkdir /programs/mcent002/analysis/JEP_analysis/output;
x mkdir /programs/mcent002/analysis/JEP_analysis/supplement;

%macro job4;

  /*Table 1*/
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/00.03.initial_placements.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/00.04.placements_by_rank.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/00.05.career_ladder.sas" ;
 
  /*Figure 1a*/
  %include "/programs/mcent002/analysis/JEP_analysis/01.01.academia70_career_path.sas" ;

  /*discussion in text*/
  %include "/programs/mcent002/analysis/JEP_analysis/00.04.academia_all_career_path.sas" ;

  /*Figure 1b*/
  %include "/programs/mcent002/analysis/JEP_analysis/01.02.industry_career_path.sas" ;

  /*discussion in text*/
  %include "/programs/mcent002/analysis/JEP_analysis/00.01.consulting_career_path.sas" ;
  %include "/programs/mcent002/analysis/JEP_analysis/00.02.finance_career_path.sas" ;
  %include "/programs/mcent002/analysis/JEP_analysis/00.03.tech_career_path.sas" ;

  /*Figure 2 and Table 2*/
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.00.kde_earn_byind.sas" ;

  /*Figure 3 and Table 2*/
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.01.kde_earn_byrank.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.02.kde_earn_byrank.sas" ;

  /*Figure 4*/
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.03.kde_earn_bysex.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.04.kde_earn_bysex.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.05.kde_earn_bysex.sas" ;
  %include "/programs/mcent002/analysis/CBDRB-FY2022-CES005-001/01.06.kde_acad_top20_bysex.sas" ;

%mend;
%job4;
