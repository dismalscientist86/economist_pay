***********************************************************************/
/*Program: 00.02.add_ein_naics.sas                                     */
/*Description: Manually adds NAICS for non-UI jobs                     */
/*Author: Erika                                                        */
/*Created: 7/8/2021                                                    */
/*input output.econ_annearn                                            */
/*output output.econ_annearn                                           */
/***********************************************************************/

options obs=max;

libname output "/projects/data/mcent002";

data econ;
  set output.econ_annearn;
     /*This portion of the code is redacted as it contains business identifing information
       but it takes the form of several lines of code assigning NAICS to employer EINs 
       generated in previous program*/
     if ein="XXXXXXXXX" then mode_naics2017fnl_emp="XXXXXX";               
   run;


data output.econ_annearn;
  set econ;
  run;
