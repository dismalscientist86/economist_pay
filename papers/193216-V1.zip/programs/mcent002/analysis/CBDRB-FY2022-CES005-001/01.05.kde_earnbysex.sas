/***************************************************************/
/*Program: 01.05.kde_earnbysex.sas                             */
/*Description: Produces KDE earnings distributions for government*/
/*             by gender                                       */
/*Author: Erika                                                */
/*Created: 9/17/2021                                           */
/***************************************************************/

*Rank jobs held each year by earnings to identify dominant employer;

libname econ "/projects//data/mcent002";

%include "../macros/disclosure/kde_median.sas";
%include "../macros/disclosure/kde_pctn.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/truncate.sas";

proc sort data=econ.econ_annearn out=econ;
  by pik year DESCENDING e;
  run;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;
  if in_econ then output;
  run;

data one ten;
  set econ (where=(phdfy<=2007 and
                   years_since in (1,10) and
                   e>=15080
                         ));
  if repec_rank>20 or repec_rank=. then rank=3;
     if repec_rank<=20 and repec_rank>5 then rank=2;
     if repec_rank in (1,2,3,4,5) then rank=1;
  if years_since=1 then output one;
  if years_since=10 then output ten;
  run;

data one;
  set one;
  if substr(mode_naics2017fnl_emp,1,2)="61" and sex=1 then e_academia_male=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and sex=2 then e_academia_female=e;

  if substr(mode_naics2017fnl_emp,1,2)="92" and sex=1 then e_govt_male=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and sex=2 then e_govt_female=e;

  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and sex=1 then e_ind_male=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and sex=2 then e_ind_female=e;
  run;

data ten;
  set ten;
  if substr(mode_naics2017fnl_emp,1,2)="61" and sex=1 then e_academia_male=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and sex=2 then e_academia_female=e;

  if substr(mode_naics2017fnl_emp,1,2)="92" and sex=1 then e_govt_male=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and sex=2 then e_govt_female=e;

  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and sex=1 then e_ind_male=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and sex=2 then e_ind_female=e;
  run;

/*Produce distributional moments for describing the graphs*/

%kde_median(one,col1,e_govt_male,median);
%kde_median(one,col2,e_govt_female,median);
%kde_pctn(one,n1,25,e_govt_male,p25); 
%kde_pctn(one,n2,25,e_govt_female,p25); 
%kde_pctn(one,k1,75,e_govt_male,p75); 
%kde_pctn(one,k2,75,e_govt_female,p75); 

data median;
  set col1 (in=in1)
      col2 (in=in2)
      k1 (rename=(p75=median) in=in3)
      k2 (rename=(p75=median) in=in4);
  length stat $30.;
  if in1 then stat="Median Male $94,040";
  if in2 then stat="Median Female $82,330";
  if in3 then stat="P75 Male $113,100";
  if in4 then stat="P75 Female $99,700";
  run;

%round4sig(median,median,median,stat);

%truncate(one,one,e_govt_male,e_govt_malet,99);
%truncate(one,one,e_govt_female,e_govt_femalet,99);


data one;
  set one median;
  run;

proc print data=median;
 title "First year Percentiles";
 run;

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $30.;
  sample="&sample. 1st year";
  if _N_=1 then output;
  run;
%mend;

%stack(ind_male,1);
%stack(ind_female,2);

data one_pctns;
  set ind_male
      ind_female;
  run;

%kde_median(ten,col1,e_govt_male,median);
%kde_median(ten,col2,e_govt_female,median);
%kde_pctn(ten,n1,25,e_govt_male,p25); 
%kde_pctn(ten,n2,25,e_govt_female,p25); 
%kde_pctn(ten,k1,75,e_govt_male,p75); 
%kde_pctn(ten,k2,75,e_govt_female,p75); 

data median10;
  set col1 (in=in1)
      col2 (in=in2)
      k1 (rename=(p75=median) in=in3)
      k2 (rename=(p75=median) in=in4);
  length stat $40.;
  if in1 then stat="Median Male $126,400";
  if in2 then stat="Median Female $117,900";
  if in3 then stat="P75 Male $173,800";
  if in4 then stat="P75 Female $152,700";
  run;

%round4sig(median10,median10,median,stat);

%truncate(ten,ten,e_govt_male,e_govt_malet,99);
%truncate(ten,ten,e_govt_female,e_govt_femalet,99);

data ten;
  set ten median10;
  run;

proc print data=median10;
 title "10th year Percentiles";
 run;

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $30.;
  sample="&sample. 10th year";
  if _N_=1 then output;
  run;
%mend;

%stack(govt_male,1);
%stack(govt_female,2);

data ten_pctns;
  set govt_male
      govt_female;
  run;

data all_pctns;
  set one_pctns
      ten_pctns;
  run;

%round4sig(all_pctns,all_pctns,p25 median p75,sample);

proc export data=all_pctns
  outfile="output/01.05.kde_govt_sex_pctns.csv" dbms=csv replace;
  run;

proc print data=all_pctns; 
title "Print of 01.05.kde_govt_sex_pctns.csv";
run;

ods graphics on /noborder outputfmt=png imagename="01.05.yr1_earn_govt_bysex";

proc sgplot data=one noborder;
 title "Government: first year after PhD";
 density e_govt_malet / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Male";
 density e_govt_femalet / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Female";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_govt_malet e_govt_femalet dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

ods graphics on /noborder outputfmt=png imagename="01.05.yr10_earn_govt_bysex";

proc sgplot data=ten noborder;
 title "Government: 10th year after PhD";
 density e_govt_malet / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Male";
 density e_govt_femalet / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Female";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_govt_malet e_govt_femalet dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

/*Produce counts for distributions*/

%macro job(dsn,sample,i);

proc sql noprint;
 create table n&i._&sample. as select count(*) as N_obs
 from &dsn.
 where e_&sample.>0;
 quit;

data n&i._&sample.;
  set n&i._&sample.;
  length sample $30.;
  sample="&sample. year &i.";
  run; 

proc append base=n_sample
            data=n&i._&sample.
            force;
run;

%mend;

%job(one,govt_male,1);
%job(one,govt_female,1);
%job(ten,govt_male,10);
%job(ten,govt_female,10);


proc export data=n_sample
  outfile="supplement/01.05.kde_govt_sex_ns.csv" dbms=csv replace;
  run;

proc print data=n_sample; 
  title "Print of supplement/01.05.kde_govt_sex_ns.csv";
  run;
