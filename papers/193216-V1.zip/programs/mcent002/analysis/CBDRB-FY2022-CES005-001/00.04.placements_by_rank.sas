/***********************************************************************/
/*Program: 00.01.table1_initial_placements.sas                          */
/*Description: Sample characteristics: Table of initial placements     */
/*REQUIRES: econ.econ_annearn                                          */
/*Author: Erika                                                        */
/*Created: 9/13/2021                                                   */
/***********************************************************************/

options obs=max;
%include "formats.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/disclosure/roundns.sas";

libname econ "/projects/data/mcent002";


/*Look at initial placements for Econ PhDs*/

data econ;
  set econ.econ_annearn (where=(years_since=1 and 
                                e>15080));
     ind=mode_naics2017fnl_emp;
  
  /*Define ranks*/
     if repec_rank>20 or repec_rank=. then rank=3;
     if repec_rank<=20 and repec_rank>5 then rank=2;
     if repec_rank in (1,2,3,4,5) then rank=1;
  /*Define cohorts*/
     if year in (2001,2002,2003,2004,2005) then cohort=1;
     if year in (2006,2007,2008,2009) then cohort=2;
     if year in (2010,2011,2012,2013) then cohort=3;
     if year in (2014,2015,2016,2017) then cohort=4;
  /*Detailed NAICS - alt format*/
     industry=put(ind,$naicsdi.);
  run;

ods listing close;

%macro job(value);

ods output OneWayFreqs=outdsn&value.;

proc freq data=econ (where=(cohort in (4) and 
                            rank=&value.));
 tables industry;
 format industry $naicsdii.;
 run;

data rank_&value. (keep=industry rank&value)
     n_rank&value. (keep=industry rank&value._n)
     n_r&value. (keep=n_rank&value.)
     ;
 set outdsn&value. (rename=(percent=rank&value.
                            frequency=rank&value._n
                            cumfrequency=n_rank&value.)
                           )
                   end=last;
 output rank_&value.;
 output n_rank&value.;
 if last then output n_r&value;
 run;

proc sort data=rank_&value.; by industry; run;
proc sort data=n_rank&value.; by industry; run;

%mend;

%job(1);
%job(2);
%job(3);

data table2;
  merge rank_1 (in=in1)
        rank_2 (in=in2)
        rank_3 (in=in3)
        ;
  by industry;
  run;

data table2_sup;
  merge n_rank1 (in=in1)
        n_rank2 (in=in2)
        n_rank3 (in=in3)
        ;
  by industry;
  run;

data table2_n;
  if _N_=1 then set n_r1;
  if _N_=1 then set n_r2;
  if _N_=1 then set n_r3;
  if _N_=1 then output;
  run;

ods listing;

%roundns(table2_n,table2_n,n_rank1 n_rank2 n_rank3);
%roundns(table2_sup,table2_round,rank1_n rank2_n rank3_n, industry);

data table2_round (drop=rank1_n rank2_n rank3_n);
  if _N_=1 then set table2_n;
  set table2_round;
  format rank1 rank2 rank3 5.2;
  rank1=(rank1_n/n_rank1)*100;
  rank2=(rank2_n/n_rank2)*100;
  rank3=(rank3_n/n_rank3)*100;
  run;

%round4sig(table2_round,table2_round,rank1 rank2 rank3, industry n_rank1 n_rank2 n_rank3);

proc export data=table2_round
  outfile="output/00.04.placements_cohort4.csv" dbms=csv replace;
  run;

proc export data=table2_sup
  outfile="supplement/00.04.placements_cohort4_n.csv" dbms=csv replace;
  run;

proc print data=table2_round; 
   title "Print of output/00.04.placements_cohort4.csv";
   run;

proc print data=table2_sup;
   title "Print of supplement/00.04.placements_cohort4_n.csv"; 
   run;

endsas;  /*DO NOT PRODUCE ALL COHORTS UNLESS NEED TO FOR SAMPLE SIZE*/

ods listing close;

%macro job(value);

ods output OneWayFreqs=outdsn2&value.;

proc freq data=econ (where=(rank=&value.));
 tables industry;
 format industry $naicsdii.;
 run;

data rank_&value. (keep=industry rank&value)
     n_rank&value. (keep=industry rank&value._n)
     n_r&value. (keep=n_rank&value.)
     ;
 set outdsn2&value. (rename=(percent=rank&value.
                            frequency=rank&value._n
                            cumfrequency=n_rank&value.)
                           )
                   end=last;
 output rank_&value.;
 output n_rank&value.;
 if last then output n_r&value;
 run;

proc sort data=rank_&value.; by industry; run;
proc sort data=n_rank&value.; by industry; run;

%mend;

%job(1);
%job(2);
%job(3);

data table2;
  merge rank_1 (in=in1)
        rank_2 (in=in2)
        rank_3 (in=in3)
        ;
  by industry;
  run;

data table2_sup;
  merge n_rank1 (in=in1)
        n_rank2 (in=in2)
        n_rank3 (in=in3)
        ;
  by industry;
  run;

data table2_n;
  if _N_=1 then set n_r1;
  if _N_=1 then set n_r2;
  if _N_=1 then set n_r3;
  if _N_=1 then output;
  run;

ods listing;

%round4sig(table2,table2,rank1 rank2 rank3, industry);
%roundns(table2_n,table2_n,n_rank1 n_rank2 n_rank3);

proc export data=table2
  outfile="output/00.04.placements_allcohorts.csv" dbms=csv replace;
  run;

proc export data=table2_n
  outfile="output/00.04.placements_allcohorts_count.csv" dbms=csv replace;
  run;

proc export data=table2_sup
  outfile="supplement/00.04.placements_allcohorts_n.csv" dbms=csv replace;
  run;

proc print data=table2; 
   title "Print of 00.04.placements_allcohorts.csv";
   run;
proc print data=table2_sup;
   title "Print of 00.04.placements_allcohorts_n.csv"; 
   run;
proc print data=table2_n; 
   title "Print of 00.04.placements_allcohorts_count.csv";
   run;

