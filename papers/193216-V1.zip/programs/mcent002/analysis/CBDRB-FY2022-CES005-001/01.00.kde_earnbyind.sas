/***************************************************************/
/*Program: 01.00.kde_earnbyind.sas                             */
/*Description: Produces KDE earnings distributions by sector   */
/*Author: Erika                                                */
/*Created: 9/17/2021                                           */
/***************************************************************/

*Rank jobs held each year by earnings to identify dominant employer;


proc sort data=econ.econ_annearn out=econ;
  by pik year DESCENDING e;
  run;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;
  if in_econ then output;
  run;

data one ten;
  set econ (where=(phdfy<=2007 and
                   years_since in (1,10) and
                   e>=15080
                         ));
  if years_since=1 then output one;
  if years_since=10 then output ten;
  run;

data one;
  set one;
  if substr(mode_naics2017fnl_emp,1,2)="61" then e_academia=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" then e_govt=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") then e_industry=e;
  run;

data ten;
  set ten;
  if substr(mode_naics2017fnl_emp,1,2)="61" then e_academia=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" then e_govt=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") then e_industry=e;
  run;

%kde_median(one,col1,e_academia,median);
%kde_median(one,col2,e_govt,median);
%kde_median(one,col3,e_industry,median);

data median;
  set col1 (in=in1)
      col2 (in=in2)
      col3 (in=in3);
  length stat $30.;
  if in1 then stat="Median Academic $83,270";
  if in2 then stat="Median Govt $91,600";
  if in3 then stat="Median Industry $108,600";
  run;

%round4sig(median,median,median,stat);

/***Truncate e_academia e_govt and e_industry at 99%*/ 

%truncate(one,one,e_academia,e_academiat,99);
%truncate(one,one,e_industry,e_industryt,99);
%truncate(one,one,e_govt,e_govtt,99);

data one;
  set one median;
  run;

proc print data=median;
title "Print of 1st year medians";
run;

%kde_median(ten,col1,e_academia,median);
%kde_median(ten,col2,e_govt,median);
%kde_median(ten,col3,e_industry,median);
 
data median10;
  set col1 (in=in1)
      col2 (in=in2)
      col3 (in=in3);
  length stat $40.;
  if in1 then stat="Median Academic $109,600";
  if in2 then stat="Median Govt $123,300";
  if in3 then stat="Median Industry $174,100";
  run;

%round4sig(median10,median10,median,stat);

%truncate(ten,ten,e_academia,e_academiat,99);
%truncate(ten,ten,e_industry,e_industryt,99);
%truncate(ten,ten,e_govt,e_govtt,99);

data ten;
  set ten median10;
  run;

proc print data=median10;
title "Print of 10 year medians";
run;

ods graphics on /noborder outputfmt=png imagename="01.00.yr1_earn_byind";

proc sgplot data=one noborder;
 title "First year after PhD";
 density e_academiat / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Academic";
 density e_govtt / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Government";
 density e_industryt / type=kernel lineattrs=(pattern=shortdash color=gray) legendlabel="Industry";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_academiat e_govtt e_industryt dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

ods graphics on /noborder outputfmt=png imagename="01.00.yr10_earn_byind";

proc sgplot data=ten noborder;
 title "10th year after PhD";
 density e_academiat / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Academic";
 density e_govtt / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Government";
 density e_industryt / type=kernel lineattrs=(pattern=shortdash color=gray) legendlabel="Industry";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_academiat e_govtt e_industryt dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

/*Produce distributional moments for describing the graphs*/

%kde_median(one,col1,e_academia,median);
%kde_median(one,col2,e_govt,median);
%kde_median(one,col3,e_industry,median);
%kde_pctn(one,n1,25,e_academia,p25); 
%kde_pctn(one,n2,25,e_govt,p25); 
%kde_pctn(one,n3,25,e_industry,p25); 
%kde_pctn(one,k1,75,e_academia,p75); 
%kde_pctn(one,k2,75,e_govt,p75); 
%kde_pctn(one,k3,75,e_industry,p75); 

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $20.;
  sample="&sample. 1st year";
  if _N_=1 then output;
  run;
%mend;

%stack(academia,1);
%stack(govt,2);
%stack(industry,3);

data one_pctns;
  set academia
      govt
      industry;
  run;

%kde_median(ten,col1,e_academia,median);
%kde_median(ten,col2,e_govt,median);
%kde_median(ten,col3,e_industry,median);
%kde_pctn(ten,n1,25,e_academia,p25); 
%kde_pctn(ten,n2,25,e_govt,p25); 
%kde_pctn(ten,n3,25,e_industry,p25); 
%kde_pctn(ten,k1,75,e_academia,p75); 
%kde_pctn(ten,k2,75,e_govt,p75); 
%kde_pctn(ten,k3,75,e_industry,p75); 

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $20.;
  sample="&sample. 10th year";
  if _N_=1 then output;
  run;
%mend;

%stack(academia,1);
%stack(govt,2);
%stack(industry,3);

data ten_pctns;
  set academia
      govt
      industry;
  run;

data all_pctns;
  set one_pctns
      ten_pctns;
  run;

%round4sig(all_pctns,all_pctns,p25 median p75,sample);

proc export data=all_pctns
  outfile="output/01.00.kde_pctns.csv" dbms=csv replace;
  run;

proc print data=all_pctns; 
title "Print of 01.00.kde_pctns.csv";
run;


/*Produce counts for distributions*/

%macro job(dsn,sample,i);

proc sql noprint;
 create table n&i._&sample. as select count(*) as N_obs
 from &dsn.
 where e_&sample.>0;
 quit;

data n&i._&sample.;
  set n&i._&sample.;
  length sample $20.;
  sample="&sample. year &i.";
  run; 

proc append base=n_sample
            data=n&i._&sample.
            force;
run;

%mend;

%job(one,academia,1);
%job(one,govt,1);
%job(one,industry,1);
%job(ten,academia,10);
%job(ten,govt,10);
%job(ten,industry,10);


proc export data=n_sample
  outfile="supplement/01.00.kde_ns.csv" dbms=csv replace;
  run;

proc print data=n_sample; 
  title "Print of supplement/01.00.kde_ns.csv";
  run;
