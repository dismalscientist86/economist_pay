/***********************************************************************/
/*Program: 00.05.career_ladder.sas                                     */
/*Description: 10 year placements for 2001-2007 cohorts                */
/*REQUIRES: econ.econ_annearn                                          */
/*Author: Erika                                                        */
/*Created: 9/13/2021                                                   */
/***********************************************************************/

options obs=max;
%include "formats.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/disclosure/roundns.sas";

libname econ "/projects/data/mcent002";

*Rank jobs held each year by earnings to identify dominant employer;

proc sort data=econ.econ_annearn out=econ;
  by pik year DESCENDING e;
  run;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;
  if in_econ then output;
  run;

/*Look at initial placements for Econ PhDs*/

data one ten;
  set econ (where=(phdfy<=2007 and e>15080));  
  /*Detailed NAICS - alt format*/
     ind=mode_naics2017fnl_emp;
     industry=put(ind,$naicsdi.);

  if years_since=1 then output one;
  if years_since=10 then output ten;
  run;

proc sort data=one; by pik; run;
proc sort data=ten; by pik; run;

data long;
  merge one (in=in1 rename=(industry=industry1))
        ten (rename=(industry=industry2))
        ;
  by pik;
  keep pik industry1 industry2;
  if in1 then output;
  run;

ods listing close;

%macro job(ind,value);

ods output OneWayFreqs=outdsn&value.;

proc freq data=long (where=(industry1="&value."));
 tables industry2;
 format industry2 $naicsdii.;
 run;

data ind_&value. (keep=industry2 &ind.)
     indj_&value. (keep=industry2 &ind.)
     n_ind&value. (keep=industry2 &ind._n)
     n_indj&value. (keep=industry2 &ind._n)
     n_cohort&value. (keep=n_&ind.)
     ;
 set outdsn&value. (rename=(percent=&ind.
                            frequency=&ind._n
                            cumfrequency=n_&ind.)
                           )
                   end=last;
 if industry2=&value. then output ind_&value.;
 if industry2~=&value. then output indj_&value.;
 if industry2=&value. then output n_ind&value.;
 if industry2~=&value. then output n_indj&value.;
 if last then output n_cohort&value;
 run;

proc sort data=indj_&value.; by descending &ind.; run;
proc sort data=n_indj&value.; by descending &ind._n; run;

data indj_&value;
  set indj_&value;
  if _N_=1 then output; 
  run;

data ind_&value;
  set ind_&value.
      indj_&value.
      ;
  run; 

data n_indj&value;
  set n_indj&value;
  if _N_=1 then output; 
  run;

data n_ind&value.;
  set n_ind&value.
      n_indj&value.
      ;
  run;

proc sort data=ind_&value.; by industry2; run;
proc sort data=n_ind&value.; by industry2; run;


%mend;

%job(other_ind,1);
%job(tech,2);
%job(finance,3);
%job(consult,4);
%job(colleges,6);
%job(govt,8);  /*7 now collapsed into 6*/

ods output OneWayFreqs=outdsn;

proc freq data=long;
 tables industry2;
 format industry2 $naicsdii.;
 run;

data n_cohort (keep=n_total)
     ;
 set outdsn (rename=(cumfrequency=n_total)
                           )
                   end=last;
 if last then output n_cohort;
 run;


data table2;
  merge ind_1 ind_2 ind_3 ind_4 ind_6 ind_8;
  by industry2;
  run;

data table2_sup;
  merge n_ind1 n_ind2 n_ind3 n_ind4 n_ind6 n_ind8;
  by industry2;
  run;

data table2_temp;
  if _N_=1 then set n_cohort1;
  if _N_=1 then set n_cohort2;
  if _N_=1 then set n_cohort3;
  if _N_=1 then set n_cohort4;
  if _N_=1 then set n_cohort6;
  if _N_=1 then set n_cohort8;
  if _N_=1 then output;
  run;

data table2_n;
  set n_cohort;
  run;

%roundns(table2_n,table2_n,n_total);
%roundns(table2_sup,table2_round,other_ind_n tech_n finance_n consult_n colleges_n govt_n,industry2);
%roundns(table2_temp,table2_temp,n_other_ind n_tech n_finance n_consult n_colleges n_govt);

data table2_round (keep=industry2 other_ind tech finance consult colleges govt);
  if _N_=1 then set table2_temp;
  set table2_round;
  format other_ind tech finance consult colleges govt 5.2;
  other_ind=(other_ind_n/n_other_ind)*100;
  tech=(tech_n/n_tech)*100;
  finance=(finance_n/n_finance)*100;
  consult=(consult_n/n_consult)*100;
  colleges=(colleges_n/n_colleges)*100;
  govt=(govt_n/n_govt)*100;
  run;


proc export data=table2_round
  outfile="output/00.05.career_ladder.csv" dbms=csv replace;
  run;

proc export data=table2_n
  outfile="output/00.05.career_ladder_count.csv" dbms=csv replace;
  run;

proc export data=table2_sup
  outfile="supplement/00.05.career_ladder_n.csv" dbms=csv replace;
  run;

ods listing;

proc print data=table2_round; 
  title "Print of output/00.05.career_ladder.csv";
  title2 "Share of placements in same sector 10 years later, second most common sector share";
  title3 "2001-2007 PhD graduates only";
  run;

proc print data=table2_n; 
  title "Print of output/00.05.career_ladder_count.csv";
  run;

proc print data=table2_sup; 
  title "Print of supplement/00.05.career_ladder_n.csv";
  run;



