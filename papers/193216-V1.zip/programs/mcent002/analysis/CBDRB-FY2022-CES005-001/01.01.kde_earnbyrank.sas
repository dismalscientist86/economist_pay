/***************************************************************/
/*Program: 01.01.kde_earnbyrank.sas                             */
/*Description: Produces KDE earnings distributions for academia   */
/*             by PhD program rank                             */
/*Author: Erika                                                */
/*Created: 9/17/2021                                           */
/***************************************************************/

*Rank jobs held each year by earnings to identify dominant employer;

libname econ "/projects//data/mcent002";

%include "../macros/disclosure/kde_median.sas";
%include "../macros/disclosure/kde_pctn.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/truncate.sas";

proc sort data=econ.econ_annearn out=econ;
  by pik year DESCENDING e;
  run;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;
  if in_econ then output;
  run;

data one ten;
  set econ (where=(phdfy<=2007 and
                   years_since in (1,10) and
                   e>=15080
                         ));
  if repec_rank>20 or repec_rank=. then rank=3;
     if repec_rank<=20 and repec_rank>5 then rank=2;
     if repec_rank in (1,2,3,4,5) then rank=1;
  if years_since=1 then output one;
  if years_since=10 then output ten;
  run;

data one;
  set one;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=1 then e_academia_top5=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=2 then e_academia_top20=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=3 then e_academia_else=e;

  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=1 then e_govt_top5=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=2 then e_govt_top20=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=3 then e_govt_else=e;

  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=1 then e_industry_top5=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=2 then e_industry_top20=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=3 then e_industry_else=e;
  run;

data ten;
  set ten;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=1 then e_academia_top5=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=2 then e_academia_top20=e;
  if substr(mode_naics2017fnl_emp,1,2)="61" and rank=3 then e_academia_else=e;

  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=1 then e_govt_top5=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=2 then e_govt_top20=e;
  if substr(mode_naics2017fnl_emp,1,2)="92" and rank=3 then e_govt_else=e;

  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=1 then e_industry_top5=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=2 then e_industry_top20=e;
  if substr(mode_naics2017fnl_emp,1,2) not in ("61","92") and rank=3 then e_industry_else=e;
  run;

%kde_median(one,col1,e_academia_top5,median);
%kde_median(one,col2,e_academia_top20,median);
%kde_median(one,col3,e_academia_else,median);

data median;
  set col1 (in=in1)
      col2 (in=in2)
      col3 (in=in3);
  length stat $30.;
  if in1 then stat="Median Top 5 $119,800";
  if in2 then stat="Median Top 20 $104,800";
  if in3 then stat="Median Other $75,920";
  run;

%round4sig(median,median,median,stat);

%truncate(one,one,e_academia_top5,e_academia_top5t,99);
%truncate(one,one,e_academia_top20,e_academia_top20t,99);
%truncate(one,one,e_academia_else,e_academia_elset,99);

data one;
  set one median;
  run;

proc print data=median;
title "Print of 1st year medians";
run;

%kde_median(ten,col1,e_academia_top5,median);
%kde_median(ten,col2,e_academia_top20,median);
%kde_median(ten,col3,e_academia_else,median);
 
data median10;
  set col1 (in=in1)
      col2 (in=in2)
      col3 (in=in3);
  length stat $40.;
  if in1 then stat="Median Top 5 $189,000";
  if in2 then stat="Median Top 20 $138,800";
  if in3 then stat="Median Other $99,170";
  run;

%round4sig(median10,median10,median,stat);

%truncate(ten,ten,e_academia_top5,e_academia_top5t,99);
%truncate(ten,ten,e_academia_top20,e_academia_top20t,99);
%truncate(ten,ten,e_academia_else,e_academia_elset,99);

data ten;
  set ten median10;
  run;

proc print data=median10;
title "Print of 10 year medians";
run;

ods graphics on /noborder outputfmt=png imagename="01.01.yr1_earn_acad_byrank";

proc sgplot data=one noborder;
 title "Academia: first year after PhD";
 density e_academia_top5t / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Top 5 PhD program";
 density e_academia_top20t / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Top 20 PhD program";
 density e_academia_elset / type=kernel lineattrs=(pattern=shortdash color=gray) legendlabel="Other PhD programs";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_academia_top5t e_academia_top20t e_academia_elset dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

ods graphics on /noborder outputfmt=png imagename="01.01.yr10_earn_acad_byrank";

proc sgplot data=ten noborder;
 title "Academia: 10th year after PhD";
 density e_academia_top5t / type=kernel lineattrs=(pattern=solid color=black) legendlabel="Top 5 PhD program";
 density e_academia_top20t / type=kernel lineattrs=(pattern=dashdashdot color=blue) legendlabel="Top 20 PhD program";
 density e_academia_elset / type=kernel lineattrs=(pattern=shortdash color=gray) legendlabel="Other PhD programs";
 refline median /axis=x label=stat lineattrs=(color=red);
 format e_academia_top5t e_academia_top20t e_academia_elset dollar8.0; 
 xaxis min=0 max=400000 display=(noline) label="Real annual earnings (2015 $)";
 yaxis display=(noline nolabel);
 run;

ods graphics off;

/*Produce distributional moments for describing the graphs*/

%kde_median(one,col1,e_academia_top5,median);
%kde_median(one,col2,e_academia_top20,median);
%kde_median(one,col3,e_academia_else,median);
%kde_pctn(one,n1,25,e_academia_top5,p25); 
%kde_pctn(one,n2,25,e_academia_top20,p25); 
%kde_pctn(one,n3,25,e_academia_else,p25); 
%kde_pctn(one,k1,75,e_academia_top5,p75); 
%kde_pctn(one,k2,75,e_academia_top20,p75); 
%kde_pctn(one,k3,75,e_academia_else,p75); 

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $30.;
  sample="&sample. 1st year";
  if _N_=1 then output;
  run;
%mend;

%stack(academia_top5,1);
%stack(academia_top20,2);
%stack(academia_else,3);

data one_pctns;
  set academia_top5
      academia_top20
      academia_else;
  run;

%kde_median(ten,col1,e_academia_top5,median);
%kde_median(ten,col2,e_academia_top20,median);
%kde_median(ten,col3,e_academia_else,median);
%kde_pctn(ten,n1,25,e_academia_top5,p25); 
%kde_pctn(ten,n2,25,e_academia_top20,p25); 
%kde_pctn(ten,n3,25,e_academia_else,p25); 
%kde_pctn(ten,k1,75,e_academia_top5,p75); 
%kde_pctn(ten,k2,75,e_academia_top20,p75); 
%kde_pctn(ten,k3,75,e_academia_else,p75); 

%macro stack(sample,i);
data &sample.;
  if _N_=1 then set col&i.;
  if _N_=1 then set n&i.;
  if _N_=1 then set k&i.;
  length sample $30.;
  sample="&sample. 10th year";
  if _N_=1 then output;
  run;
%mend;

%stack(academia_top5,1);
%stack(academia_top20,2);
%stack(academia_else,3);

data ten_pctns;
  set academia_top5
      academia_top20
      academia_else;
  run;

data all_pctns;
  set one_pctns
      ten_pctns;
  run;

%round4sig(all_pctns,all_pctns,p25 median p75,sample);

proc export data=all_pctns
  outfile="output/01.01.kde_acad_rank_pctns.csv" dbms=csv replace;
  run;

proc print data=all_pctns; 
title "Print of 01.01.kde_acad_rank_pctns.csv";
run;


/*Produce counts for distributions*/

%macro job(dsn,sample,i);

proc sql noprint;
 create table n&i._&sample. as select count(*) as N_obs
 from &dsn.
 where e_&sample.>0;
 quit;

data n&i._&sample.;
  set n&i._&sample.;
  length sample $30.;
  sample="&sample. year &i.";
  run; 

proc append base=n_sample
            data=n&i._&sample.
            force;
run;

%mend;

%job(one,academia_top5,1);
%job(one,academia_top20,1);
%job(one,academia_else,1);
%job(ten,academia_top5,10);
%job(ten,academia_top20,10);
%job(ten,academia_else,10);


proc export data=n_sample
  outfile="supplement/01.01.kde_acad_rank_ns.csv" dbms=csv replace;
  run;

proc print data=n_sample; 
  title "Print of supplement/01.01.kde_acad_rank_ns.csv";
  run;
