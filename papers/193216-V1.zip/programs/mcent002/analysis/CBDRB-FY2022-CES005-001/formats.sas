/****************************************************************/
/*Program: formats.sas                                          */
/*Description: Formats for the linked SED-LEHD-W2 file          */
/*                                                              */
/****************************************************************/

/*Value labels for....*/ 


/*COHORT YEAR*/
proc format;
   value cohort
         2001-2005="2001-2005"
         2006-2009="2006-2009"
         2010-2013="2010-2013"
         2014-2017="2014-2017"
    ;
run;


/*Detailed NAICS - alt format invalue*/
proc format;
  value $naicsdi
  "111111"-"453998","454390","481111"-"485210","485320"-"488999","491100"-"493190","511110"-"511199","512110","531110"-"533110","551111"-"551114","561110"-"562998","621111"-"624410","711110"-"721191","721211"-"814110"="1"
  "454110","485310","511210","517311"-"519190","541511"-"541519","541713"-"541715","721199"="2"
  "521110","522110"-"525990"="3"
  "541110"-"541199","541430","541211"-"541219","541320"-"541380","541611"-"541620","541690","541810"-"541990","541720"="4"
  "611310"="6"
  "611110","611210","611410"-"611710"="6"
  "921110"-"928120"="8"
;

/*Detailed NAICS - alt format*/
proc format;
  value $naicsdii
  "1"="Other Industry"
  "2"="Technology Firms"
  "3"="Finance & Banking"
  "4"="Consulting & SS Research"
  "6"="Colleges and Universities"
  /*"7"="Other Education"*/
  "8"="Government"
;

/*Detailed NAICS - alt format2*/
proc format;
  value $naicsdw
  "1"-"5"="Industry"
  "6"="Academia"
  "8"="Government"
;


/*NAICS_SECTOR - alt2 format*/
proc format;
  value $naicsaltt
  "11"-"49","51"-"54","55"-"56","62"-"81"="Industry"
  "61"="Academia"
  "92"="Government, including Federal Reserve"
;
