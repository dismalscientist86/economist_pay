/**********************************************************/
/*Program: kde_median.sas                                 */
/*Author: Erika                                           */
/*Description: Takes an input file and produces a new     */
/*             output file with the median value of       */
/*             'var' calculated from a kernel density     */
/*             estimate.                                  */
/*Syntax:                                                 */
/*  %kde_median(dsn,outdsn,var);                          */
/*Where:                                                  */
/*DSN: input data set                                     */
/*OUTDSN: output data set                                 */
/*VAR: variable to calculate kde median of                */
/*OUTVAR: name of output variable                         */
/**********************************************************/

%macro kde_median(dsn,outdsn,var,outvar);

ods listing close;
proc kde data=&dsn.;
  univar &var. /percentiles=50;
  ods output Percentiles=&outdsn.;
run;
ods listing;

data &outdsn. (keep=&outvar.);
  set &outdsn.;
  &outvar.=&var.;
  run;


%mend kde_median;



 
