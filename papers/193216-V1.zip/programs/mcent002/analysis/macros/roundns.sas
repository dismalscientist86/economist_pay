/**********************************************************/
/*Program: roundNs.sas                                    */
/*Author: Erika                                           */
/*Description: Takes an input file and produces a new     */
/*             output file where all variables in         */
/*             'varlist' are rounded according to         */
/*             rounding rules for observation counts      */
/*Syntax:                                                 */
/*  %roundNs(dsn,outdsn,varlist,keeplist);                */
/*Where:                                                  */
/*DSN: input data set                                     */
/*OUTDSN: output data set                                 */
/*VARLIST: list of values to round                        */
/*KEEPLIST: list of other values to retain                */
/**********************************************************/

%macro roundNs(dsn,outdsn,varlist,keeplist);

data &outdsn.(keep=&varlist. &keeplist.);
 set &dsn.;
  %let i=1;
   %do %until("%scan(&varlist.,&i.)"="");
     %let inputvar=%scan(&varlist.,&i);
        if &inputvar.=. then &inputvar=.; 
        if &inputvar.>=0 and &inputvar.<15 then &inputvar=15;
        if &inputvar.>=15 and &inputvar.<=99 then &inputvar=round(&inputvar.,10);
        if &inputvar.>=100 and &inputvar.<=999 then &inputvar=round(&inputvar.,50);
        if &inputvar.>=1000 and &inputvar.<=9999 then &inputvar=round(&inputvar.,100);
        if &inputvar.>=10000 and &inputvar.<=99999 then &inputvar=round(&inputvar.,500);
        if &inputvar.>=100000 and &inputvar.<=999999 then &inputvar=round(&inputvar.,1000);
        if &inputvar.>=1000000 then &inputvar.=round(&inputvar.,10**(int(log10(abs(&inputvar.)))-3));

      %let i=%eval(&i+1);
    %end;
  run;


%mend roundNs;



 
