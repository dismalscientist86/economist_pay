/**********************************************************/
/*Program: round4sig.sas                                 */
/*Author: Erika                                           */
/*Description: Takes an input file and produces a new     */
/*             output file where all variables in         */
/*             'varlist' are rounded to four significant  */
/*             digits for disclosure.                     */
/*Syntax:                                                 */
/*  %round4(dsn,outdsn,varlist);                          */
/*Where:                                                  */
/*DSN: input data set                                     */
/*OUTDSN: output data set                                 */
/*VARLIST: list of variables to round to 4 significant digits*/
/*VARLIST2: list of other variables to retain             */ 
/**********************************************************/

%macro round4sig(dsn,outdsn,varlist,varlist2);

data &outdsn.(keep=&varlist2. &varlist.);
 set &dsn.;
  %let z=1;
   %do %until("%scan(&varlist.,&z.)"="");
     %let inputvar=%scan(&varlist.,&z);

       if int(&inputvar.) ne 0 then do;
          &inputvar.=round(&inputvar.,10**(int(log10(abs(&inputvar.)))-3));
       end;

       if int(&inputvar.) eq 0 and &inputvar. ne 0 then do;
         &inputvar.=round(&inputvar.,10**(-1*(abs(int(log10(abs(&inputvar.))))+4)));
       end;

      %let z=%eval(&z+1);
    %end;
  run;


%mend round4sig;



 
