/**********************************************************/
/*Program: kde_pctn.sas                                 */
/*Author: Erika                                           */
/*Description: Takes an input file and produces a new     */
/*             output file with the median value of       */
/*             'var' calculated from a kernel density     */
/*             estimate.                                  */
/*Syntax:                                                 */
/*  %kde_pctn(dsn,outdsn,pctn,var,outvar);                     */
/*Where:                                                  */
/*DSN: input data set                                     */
/*OUTDSN: output data set                                 */
/*PCTN: Percentile to calculate                           */
/*VAR: variable to calculate kde median of                */
/*OUTVAR: name of output variable                         */
/**********************************************************/

%macro kde_pctn(dsn,outdsn,pctn,var,outvar);

ods listing close;
proc kde data=&dsn.;
  univar &var. /percentiles=&pctn.;
  ods output Percentiles=&outdsn.;
run;
ods listing;

data &outdsn. (keep=&outvar.);
  set &outdsn.;
  &outvar.=&var.;
  run;

%mend kde_pctn;



 
