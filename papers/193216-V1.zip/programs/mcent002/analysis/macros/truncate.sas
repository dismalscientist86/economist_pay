/********************************************************************/
/* Macro: truncate.sas                                               */
/* Author: Erika                                                    */
/* Description:  This macro truncates the upper X tail of the      */
/* distribution by creating a new variable that sets the           */
/* values above X percentile to missing                            */
/* It requires 5 variables:                                         */
/* indsn: name of input dataset                                     */
/* outdsn: name of output dataset                                   */
/* var: variable to truncate                                        */
/* pctnvar: name of truncated variable                              */
/* m: percentile to truncate at                                     */ 
/********************************************************************/

%macro truncate(indsn,outdsn,var,pctnvar,m);

proc univariate noprint data=&indsn.;
 var &var.;
 output out=quintile pctlpts=&m. pctlpre=pct;
run;

data _null_;
 set quintile;
 call symput('q1',pct&m.);
run;

data &outdsn;
 set &indsn;
 &pctnvar.=&var.;
 if &var. ge &q1 then &pctnvar.=.;
run;

%put &pctnvar. is &var. with values >=&q1. set to missing;

%mend truncate;


