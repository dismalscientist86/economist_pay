***********************************************************************/
/*Program: 01.02_industry_career_path.sas                             */
/*Description: Tracks job ladders across 10 years for economists      */
/*             with initial placement in consulting/finance           */
/*REQUIRES: econ.econ_annearn                                         */
/*Author: Erika                                                        */
/*Created: 1/21/2023                                                   */
/***********************************************************************/

options obs=max;
%include "formats.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/disclosure/roundns.sas";

libname econ "/projects/data/mcent002";

/*Create a cohort with 10 year outcomes, people who received PhDs between 2001 and 2010*/

*Rank jobs held each year by earnings to identify dominant employer;

proc sort data=econ.econ_annearn (where=(phdfy<=2010)) out=econ;
  by pik year DESCENDING e;
  run;

*Create annual earnings for all jobs;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;
  if in_econ then output;
  run;

/*output piks where first placement was consulting or finance*/

data consult (keep=pik);
 set econ;
 if years_since=1 and (naics2017_2digit="54" or naics2017_2digit="52") then output;
 run;

data consult;
  merge econ (in=in_econ)
        consult (in=in_consult);
  by pik;
  if in_consult then output;
  run;

data initial_sein (keep=pik initial_sein initial_ein initial_naics);
  set consult;
  if years_since=1 then do;
     initial_sein=sein;
     initial_ein=ein;
     initial_naics=naics2017_2digit;
     output;
   end;
  run;

data consult;
  merge consult
        initial_sein;
  by pik;
  run;

data consult1;
  set consult (where=(substr(initial_sein,1,3) ne "   "));
  mv=compare(sein,initial_sein,'li');

  if mv eq 0 and initial_naics="54" then cat=0; /*initial consulting placement*/
  if mv eq 0 and initial_naics="52" then cat=1; /*initial finance placement*/

  if mv ne 0 and initial_naics="54" and naics2017_2digit not in ("61") then cat=2; /*initial consulting, job mover, industry or govt*/
  if mv ne 0 and initial_naics="52" and naics2017_2digit not in ("61") then cat=3; /*initial finance, job mover, industry or govt*/

  if mv ne 0 and initial_naics="54" and naics2017_2digit="61" then cat=4; /*initial consulting, moves to academia*/
  if mv ne 0 and initial_naics="52" and naics2017_2digit="61" then cat=4; /*initial finance, moves to academia*/

run;

data consult2;
  set consult (where=(substr(initial_ein,1,3) ne "   "));
  mv=compare(ein,initial_ein,'li');

  if mv eq 0 and initial_naics="54" then cat=0; /*initial consulting placement*/
  if mv eq 0 and initial_naics="52" then cat=1; /*initial finance placement*/

  if mv ne 0 and initial_naics="54" and naics2017_2digit not in ("61") then cat=2; /*initial consulting, job mover, industry or govt*/
  if mv ne 0 and initial_naics="52" and naics2017_2digit not in ("61") then cat=3; /*initial finance, job mover, industry or govt*/

  if mv ne 0 and initial_naics="54" and naics2017_2digit="61" then cat=4; /*initial consulting, moves to academia*/
  if mv ne 0 and initial_naics="52" and naics2017_2digit="61" then cat=4; /*initial finance, moves to academia*/

run;

data consult;
 set consult1 consult2;
 run;

/*Make a long pik-level file for consulting workers with 10 years of continuous earnings above 
  the earnings threshold*/

%macro job;
 %do i=1 %to 10;

   data d&i. (keep=pik cat&i. e&i.);
     set consult (where=(years_since=&i.));
      cat&i.=cat;
      e&i.=e;
      if e&i.>15080 then output;
     run;

   proc sort data=d&i.; by pik; run;
  %end;
%mend;
%job;

data long;
  merge d1 d2 d3 d4 d5 
        d6 d7 d8 d9 d10
        ;
  by pik;
   %macro job2;
     %do i=1 %to 10;
       if e&i.=. then delete;
     %end;
   %mend;
   %job2; 
  /*imputing a couple of missing initial obs that persist despite multiple debugs*/
  if cat1=. then cat1=0;
  if e1=. then e1=e2*.9;
  /*some cases with extreme wage growth from initial year we may only have part-year earnings*/
  if e1<(.6*e2) then e1=e2*.9;
  /*earnings growth from initial placement*/
  edelta1=0;
  edelta2=(e2-e1)/e1;
  edelta3=(e3-e1)/e1;
  edelta4=(e4-e1)/e1;
  edelta5=(e5-e1)/e1;
  edelta6=(e6-e1)/e1;
  edelta7=(e7-e1)/e1;
  edelta8=(e8-e1)/e1;
  edelta9=(e9-e1)/e1;
  edelta10=(e10-e1)/e1;

  run;

*proc print data=long (obs=100); 
*run;

%macro job3;
  %do i=1 %to 10;

   proc summary data=long;
    class cat&i.;
    var e&i. edelta&i;
    output out=y&i. (drop=_TYPE_ _FREQ_) n(e&i.)=n&i. mean(e&i.)=ave_e&i. mean(edelta&i.)=ave_edelta&i.;
   run;

   proc sort data=y&i.; by cat&i.; run;

  %end;
%mend;
%job3;

data graph (drop=ave_e1-ave_e9 ave_edelta1-ave_edelta9);
  merge y1 (rename=(cat1=cat))
        y2 (rename=(cat2=cat)) 
        y3 (rename=(cat3=cat)) 
        y4 (rename=(cat4=cat)) 
        y5 (rename=(cat5=cat)) 
        y6 (rename=(cat6=cat)) 
        y7 (rename=(cat7=cat))
        y8 (rename=(cat8=cat))
        y9 (rename=(cat9=cat))
        y10 (rename=(cat10=cat))
        ;
  by cat;
  length cat_long $50.;
  if cat=. then cat_long="All";
  if cat=0 then cat_long="Initial Consulting Placement"; 
  if cat=1 then cat_long="Initial Finance Placement"; 
  if cat=2 then cat_long="Consulting Placement, Other Industry or Govt"; 
  if cat=3 then cat_long="Finance Placement, Other Industry or Govt";  
  if cat=4 then cat_long="Moves to Academia";  
  run;

%roundns(graph,graph_round,n1 n2 n3 n4 n5 n6 n7 n8 n9 n10,ave_e10 ave_edelta10 cat_long cat);
%round4sig(graph_round,graph_round,ave_e10 ave_edelta10,cat cat_long n1 n2 n3 n4 n5 n6 n7 n8 n9 n10);

proc export data=graph_round
  outfile="output/01.02.industry_career_path.csv" dbms=csv replace;
  run;

proc print data=graph_round; 
  title "Print of output/01.02.industry_career_path.csv";
  run;

data graph_n (keep=cat cat_long n1 n2 n3 n4 n5 n6 n7 n8 n9 n10);
  set graph;
  run;

data graph_ave_n (keep=cat cat_long n10 ave_e10 ave_edelta10);
  set graph;
  run;

proc export data=graph_n
  outfile="supplement/01.02.industry_career_path_n.csv" dbms=csv replace;
  run;

proc export data=graph_ave_n
  outfile="supplement/01.02.industry_career_path_ave_n.csv" dbms=csv replace;
  run;

proc print data=graph_n;
  title "Print of supplement/01.02.industry_career_path_n.csv";
  run;

proc print data=graph_ave_n;
  title "Print of supplement/01.02.industry_career_path_ave_n.csv";
  run;


