***********************************************************************/
/*Program: 00.03_tech_career_paths.sas                                */
/*Description: Tracks job ladders across 4 years for economists       */
/*             with initial placement in tech firm                    */
/*REQUIRES: econ.econ_annearn                                         */
/*Author: Erika                                                        */
/*Created: 1/21/2023                                                   */
/***********************************************************************/

options obs=max;
%include "formats.sas";
%include "../macros/disclosure/round4sig.sas";
%include "../macros/disclosure/roundns.sas";

libname econ "/projects/data/mcent002";

/*Create a cohort with 5 year outcomes, people who received PhDs between 2001 and 2016*/

*Rank jobs held each year by earnings to identify dominant employer;

proc sort data=econ.econ_annearn (where=(phdfy<=2015)) out=econ;
  by pik year DESCENDING e;
  run;

*Create annual earnings for all jobs;

proc summary data=econ;
  var e;
  class pik year;
  types pik*year;
  output out=ann_earn (drop=_type_ _freq_) sum=;
  run;

*Create a pik year file with dominant employer and then attach all earnings in year;

data econ (drop=e);
  set econ;
  by pik year;
  if first.pik or first.year then output;
  run;

data econ;
  merge econ (in=in_econ)
        ann_earn;
  by pik year;

  /*Detailed NAICS - alt format*/
  ind=put(mode_naics2017fnl_emp,$naicsdi.);

  /*Sometimes the merge for six digit failed but Dani's 2 digit is available*/
  if ind=. then do;
     if naics2017_2digit="52" then ind="3";
     if naics2017_2digit="54" then ind="4";
     if naics2017_2digit="61" then ind="6";
     if naics2017_2digit="92" then ind="8";
  end;

  if in_econ then output;
  run;

/*output piks where first placement was technology firm (ind=2)*/

data consult (keep=pik);
 set econ;
 if years_since=1 and ind="2" then output;  
 run;

data consult;
  merge econ (in=in_econ)
        consult (in=in_consult);
  by pik;
  if in_consult then output;
  run;

data initial_sein (keep=pik initial_sein);
  set consult;
  if years_since=1 then do;
     initial_sein=sein;
     output;
   end;
  run;

data consult;
  merge consult
        initial_sein;
  by pik;
  run;

data consult;
  set consult;
  cat=compare(sein,initial_sein,'li');
  if cat ne 0 and ind="2" then cat=1;
  if cat ne 0 and ind not in ("2","6","8") then cat=2;
  if ind="6" then cat=3;
  if ind="8" then cat=2; /*collapse govt with industry because too few obs after rounding*/
run;


/*Make a long pik-level file for consulting workers with 10 years of continuous earnings above 
  the earnings threshold*/

%macro job;
 %do i=1 %to 5;

   data d&i. (keep=pik cat&i. e&i.);
     set consult (where=(years_since=&i.));
      cat&i.=cat;
      e&i.=e;
      if e&i.>15080 then output;
     run;

   proc sort data=d&i.; by pik; run;
  %end;
%mend;
%job;

data long;
  merge d1 d2 d3 d4 d5 
        ;
  by pik;
   %macro job2;
     %do i=1 %to 4;
       if e&i.=. then delete;
     %end;
   %mend;
   %job2; 
  /*imputing a couple of missing initial obs that persist despite multiple debugs*/
  if cat1=. then cat1=0;
  if e1=. then e1=e2*.9;
  /*some cases with extreme wage growth from initial year we may only have part-year earnings*/
  if e1<(.6*e2) then e1=e2*.9;
  /*earnings growth from initial placement*/
  edelta1=0;
  edelta2=(e2-e1)/e1;
  edelta3=(e3-e1)/e1;
  edelta4=(e4-e1)/e1;
  edelta5=(e5-e1)/e1;
  run;

*proc print data=long (obs=100); 
*run;

%macro job3;
  %do i=1 %to 5;

   proc summary data=long;
    class cat&i.;
    var e&i. edelta&i;
    output out=y&i. (drop=_TYPE_ _FREQ_) n(e&i.)=n&i. mean(e&i.)=ave_e&i. mean(edelta&i.)=ave_edelta&i.;
   run;

   proc sort data=y&i.; by cat&i.; run;

  %end;
%mend;
%job3;

data graph (drop=ave_e1-ave_e4 ave_edelta1-ave_edelta4);
  merge y1 (rename=(cat1=cat))
        y2 (rename=(cat2=cat)) 
        y3 (rename=(cat3=cat)) 
        y4 (rename=(cat4=cat))  
        y5 (rename=(cat5=cat))  
        ;
  by cat;
  length cat_long $30.;
  if cat=. then cat_long="All";
  if cat=0 then cat_long="Initial Tech Placement"; 
  if cat=1 then cat_long="Tech, Switched Jobs"; 
  if cat=2 then cat_long="Moved to Other Industry or Govt"; 
  if cat=3 then cat_long="Moved to Academia"; 
  run;

%roundns(graph,graph_round,n1 n3 n5,ave_e5 ave_edelta5 cat_long cat);
%round4sig(graph_round,graph_round,ave_e5 ave_edelta5,cat cat_long n1 n3 n5);

proc export data=graph_round
  outfile="output/00.03.tech_career_path.csv" dbms=csv replace;
  run;

proc print data=graph_round; 
  title "Print of output/00.03.tech_career_path.csv";
  run;

data graph_n (keep=cat cat_long n1 n3 n5);
  set graph;
  run;

data graph_ave_n (keep=cat cat_long n5 ave_e5 ave_edelta5);
  set graph;
  run;

proc export data=graph_n
  outfile="supplement/00.03.tech_career_path_n.csv" dbms=csv replace;
  run;

proc export data=graph_ave_n
  outfile="supplement/00.03.tech_career_path_ave_n.csv" dbms=csv replace;
  run;

proc print data=graph_n;
  title "Print of supplement/00.03.tech_career_path_n.csv";
  run;

proc print data=graph_ave_n;
  title "Print of supplement/00.03.tech_career_path_ave_n.csv";
  run;


