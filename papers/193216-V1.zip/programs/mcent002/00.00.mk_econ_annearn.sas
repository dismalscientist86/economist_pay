/***********************************************************************/
/*Program: 00.00.mk_econ_annearn.sas                                   */
/*Description: This program does some basic data exploration of Dani's */
/*             core data file linking SED data to LEHD and W2          */
/*             and creates a file of PhD economists for analysis       */
/*INPUTS: econ.sed_annualearn_combo                                    */
/*OUTPUTS: output.econ_annearn                                         */
/*Author: Erika                                                        */
/*Created: 6/16/2021                                                   */
/*Updated: 7/8/2021 - adding more race and detailed NAICS              */
/*Updated: 8/6/2021 - adding phd institution to create ranks           */
/*Updated: 9/23/2021 - adding phdfield and expanding economist sample  */
/*Updated: 2/2/2023 - updated W2 data to 2021 now included in analysis file */
/***********************************************************************/

options obs=max;
%include "formats.sas";

/*Note: Dani's main analysis file is sed_annualearn_combo, located in the econ directory below*/


data econ (keep=pik year sein ein phdfy phdfield agedoc phdqtr sex us_citiz race_agg race2 race_agg2
                  economist e years_since pdemploy2 naics2017_2digit);
  set econ.sed_annualearn_combo2021;
    label phdfy="Academic year PhD received (July(t-1)-June(t))"
          agedoc="Age at Doctorate (SED)"
          phdqtr="Quarter PhD received (in LEHD qtime)"
          sex="1=Male, 2=Female (SED, completed with ICF)"
          us_citiz="1=U.S. citizen or perm resident, 0=not a citizen (derived from SED)"
          race_agg="Race/ethnity/citizenship (derived from SED/ICF)"
          race_agg2="Race_agg but with AIAN,NHPI,Two or more races recoded to Other)"
          economist="1 if Econ PHD, 0 if PHD not in Econ"
          e="Annual earnings (2015$)"
          years_since="Years since PhD received"
          ein="Federal EIN"
          sein="State EIN"
          pdemploy2="First post-PhD employer from SED, missing if no plans"
          naics2017_2digit="2-digit NAICS with Reserve Banks recoded to 92"
          year="Calendar year, earnings data"
          years_since="Years since PhD granted (year-phdfy)"
          race2="RACE2 edited race variable from the SED"
          ;
    if economist=1 and e>0 then output;
  run;

/*Add back detailed NAICS*/

proc sort data=econ; 
  by sein year; 
  run; 

proc sort data=int.ecf_interleave_sein_t13 (keep=sein year quarter mode_naics2017fnl_emp) out=ecf; 
  by sein year quarter;
  run;

data ecf (keep=sein year mode_naics2017fnl_emp);
  set ecf;
  by sein year quarter;
  if first.sein or first.year then output;
  run;

data econ;
  merge econ (in=in_SED)
        ecf (in=in_ui)
        ;
  by sein year;
  label ui_flag="1 if job in UI, 0 otherwise";
  ui_flag=0; 
  if in_SED then do;
     if in_ui then ui_flag=1;
     output;
  end;
  run;

/*Establish sort order on file*/

proc sort data=econ out=output.econ_annearn;
  by pik year sein ein;
  run;

proc contents data=output.econ_annearn2021; run;







