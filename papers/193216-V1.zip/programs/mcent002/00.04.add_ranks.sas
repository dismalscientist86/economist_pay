***********************************************************************/
/*Program: 00.04.add_ranks.sas                                       */
/*Description: Imports PhD program ranks and links to PhD institution */
/*Author: Erika                                                        */
/*Created: 8/26/2021                                                    */
/*input output.econ_annearn  output.depart_rankings.csv                 */
/*output output.econ_annearn                                           */
/***********************************************************************/

options obs=max;

libname output "/projects/data/mcent002";

proc import datafile="/projects/data/mcent002/dept_rankings.csv"
     out=dept_rankings
     dbms=csv replace;
getnames=yes;
run;

data dept_rankings;
  set dept_rankings;
  phdinst=put(IPEDS_number,6.);
  drop IPEDS_number;
  run;

proc sort data=dept_rankings; 
  by phdinst;
  run;

proc sort data=output.econ_annearn out=econ;
  by phdinst;
  run;

data econ;
  merge econ (in=in_econ)
        dept_rankings (rename=(name=phdinst_name) 
                       in=in_rank
                       );
  by phdinst;
  if amir_knauff_rank=99 then amir_knauff_rank=.;  /*used 99 when creating file to indicate 'not ranked'*/
  if in_econ then output;
  run;

proc sort data=econ; by pik year; run;

proc print data=econ (obs=50); 
  var pik phdinst coupe_rank repec_rank amir_knauff_rank e year;
run;

data output.econ_annearn;
  set econ;
  run;
