***********************************************************************/
/*Program: 00.03.add_phdinst.sas                                       */
/*Description: Manually adds PHDINST to analysis file                  */
/*Author: Erika                                                        */
/*Created: 8/6/2021                                                    */
/*input output.econ_annearn  output.sed_pik                            */
/*output output.econ_annearn                                           */
/***********************************************************************/

options obs=max;

libname output "/projects/data/mcent002";

proc sort data=output.econ_annearn out=econ;
  by pik;
  run;

proc sort data=output.sed_pik (keep=pik PHDINST) out=sed nodupkey;
  by pik;
  run;

data econ;
  merge econ (in=in_econ)
        sed;
  by pik;
  if in_econ then output;
  run;

data output.econ_annearn;
  set econ;
  run;

