/***********************************************************************/
/*Program: 00.01.add_ein_naics.sas                                     */
/*Description: Manually adds NAICS for non-UI jobs                     */
/*Author: Erika                                                        */
/*Created: 7/8/2021                                                    */
/***********************************************************************/

options obs=max;

libname output "/projects/data/mcent002";

data econ;
  set output.econ_annearn;
  run;

proc summary data=econ (where=(ui_flag=0));
  class ein;
  types ein;
  var e;
  output out=w2_eins (drop=_type_ _freq_) n=n_obs;
  run;

proc sort data=w2_eins;
  by DESCENDING n_obs;
  run;

proc print data=w2_eins;
run;
