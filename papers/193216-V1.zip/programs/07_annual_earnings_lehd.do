/*************************
Program name: 04_annual_earnings.do
Created by: Dani Sandler
Created on: February 2, 2021
Purpose: Create an annual earnings series, using fiscal/academic year earnings 
  (earnings year starts in Q4 of t-1)
Modifications: 2/25/21 - DHS - Added a floor of minimum wage full time equivalent earnings to 
			  be included in earnings average
			     - Excluded NHPI from graph by race. Weird outlier made it hard to read
	      3/3/20 - Changed data to ICF merge. 
			Harmonized ICF & SED race. Changed graphs to used harmonized values.
	      6/29/2021 - Added Institution Rank measures
	      7/14/2021 - Keep full NAICS code to break out more detailed industries
		  1/25/2023 - Comment out quarter drop. Rename final file with 2021 to distinguish from previous final file
***************************/
 
*Master setup program
do 00_master_SED_LEHD.do

log using $programs/logs/06_annual_earnings_lehd${c_date}.log, replace

use $mydata/icf_phf_sed_merge.dta, clear
summ

*Drop last three quarters without data
*drop e134 e135 e136

*Use successor variable to handle acquisitions/mergers/other sein changes
*replace sein=sein_succ if sein_succ!=""

*Rename Ph.D. quarter more sensibly
rename lehdquarter phdqtr

*Rename first_acc qtime to match to ECF
rename first_acc qtime

destring phdinst, replace


*Keep variables of interest
keep e21-e145 sex phdfy phdqtr agedoc race_harm race2 white black hispanic asian aian nhpi twoplus us_born us_citiz pik qtime sein economist phdinst phdcarn race_agg* pdemploy2 phdfield

*Collapse to one observation per person (combining multiple employers)
gcollapse (sum) e21-e145 (max) qtime (firstnm) phdfy agedoc sex race_harm race2 white black hispanic asian aian nhpi twoplus us_born us_citiz phdqtr economist phdinst phdcarn race_agg* pdemploy2 phdfield, by(pik sein) labelformat(#sourcelabel#)

reshape long e, i(pik sein) j(qtr)

keep if qtr>phdqtr
gen qtrs_since=qtr-phdqtr

*Drop pik-seins with no post-phd earnings observations
bysort pik sein: gegen total_earn=total(e)
summ total_earn, d
drop if total_earn==0

tempfile phf
save `phf'

*Bring in ECF for industries
use ${mydata}/ecf_SED_match.dta, clear
keep sein qtime mode_naics2017fnl_emp

*How many unique SEINs
unique sein

*How many unique 6 digit industries
unique mode_naics2017fnl_emp

*15 most frequent
groups mode_naics2017fnl_emp, order(h) show(freq percent) select(25)

*Get two and three digit industries
gen naics2017_2digit=substr(mode_naics2017fnl_emp,1,2)
groups naics2017_2digit, order(h) show(freq percent) select(25)

*Recode Federal Reserve Banks into sector 92
*replace naics2017_2digit="92" if mode_naics2017fnl_emp=="521110"

#delimit ;
label define indlabel 
11 "11 - Agriculture"
21 "21 - Mining"
22 "22 - Utilities"
23 "23 - Construction"
31 "31/32/33 - Manufacturing"
32 "31/32/33 - Manufacturing"
33 "31/32/33 - Manufacturing"
42 "42 - Wholesale Trade"
44 "44/45 - Retail Trade"
45 "45/45 - Retail Trade"
48 "48/49 - Transportation"
49 "48/49 - Transportation"
51 "51 - Information"
52 "52 - Finance"
53 "53 - Real Estate"
54 "54 - Professional Services"
55 "55 - Management of Companies"
56 "56 - Admininstrative Services"
61 "61 - Education"
62 "62 - Health Care"
71 "71 - Arts and Entertainment"
72 "72 - Accommodation and Food"
81 "81 - Other Services"
92 "92 - Public Administration"
;
#delimit cr

gen naics2017_3digit=substr(mode_naics2017fnl_emp,1,3)
groups naics2017_3digit, order(h) show(freq percent) select(25)

tempfile ecf
save `ecf'


*Bring in RePEC instiution ranks
insheet using ${mydata}/Repec_department_rankings.csv, clear
rename ipeds_num phdinst
rename repecrank repec_rank
drop if missing(phdinst)
sort phdinst repec_rank
drop if phdinst==phdinst[_n-1]
keep repec_rank phdinst
tempfile repec
save `repec', replace


*Merge them all together
use `phf', clear
merge m:1 sein qtime using `ecf'
tab _merge
keep if _merge==3
drop _merge


*Annual earnings, starting with year post-phd.
gen years_since=ceil(qtrs_since/4)

*First Winsorize before aggregating
gen pos_earn=e if e!=0
summ pos_earn, d
bysort qtr: gegen winsor=pctile(e),p(99)
replace e=winsor if e>winsor
drop pos_earn winsor

*And use real (2015) dollars
gen year=floor(1985+((qtr-1)/4))
merge m:1 year using ${mydata}/cpi_6717.dta
keep if _merge==3
drop _merge
replace e=e*237.017/cpi

*Merge on RePEC institution rankings
merge m:1 phdinst using `repec', gen(repec_merge)
drop if repec_merge==2
drop repec_merge

#delimit ;
*Aggregate to annual earnings, by year since Ph.D.; 
collapse (sum) e (firstnm) *naics2017* phdfy agedoc sex race_harm race2 
	white black hispanic asian aian nhpi twoplus us_born us_citiz 
	phdqtr economist phdinst* phdcarn repec_rank race_agg* pdemploy2 phdfield, by(pik sein years_since) ;

save ${mydata}/SED_annualearn2021.dta, replace;


