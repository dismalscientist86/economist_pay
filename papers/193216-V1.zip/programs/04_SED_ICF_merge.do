/***************************
*Program name: SED_ICF_merge.do
*Purpose: To match the SED-PHF matched data to the ICF
*Created by: Dani Sandler
*Created on: June 4, 2020
*Changes: 7/13/20 - DHS - Merge in variables from survey data
	  4/21/21 - DHS - Added citizenship variable from SED & ICF
	  9/20/21 - DHS - Combined permanent residents with U.S. citizens. citiz=="2"|citiz=="A"
****************************/
do 00_master_SED_LEHD.do

log using $programs/logs/04_SED_ICF_merge${c_date}.log, replace


*Just checking that the pik variables are consistently formatted across datasets
use ${mydata}/SED_2001_2017_piks.dta, clear
codebook pik

import sas using ${lehd_icf}/icf_us.sas7bdat, clear case(lower)

summ

codebook pik

gduplicates report pik

rename sex sex_icf
rename race race_icf
gen us_born_icf=(pob=="A")

*First match icf to PIKs
merge 1:1 pik using ${mydata}/SED_2001_2017_piks.dta
drop if _merge==1
drop _merge


*Then match these to the SED-LEHD matched data
*merge 1:m pik using ${mydata}/phf_sed_merge.dta //Data from 01b
merge 1:m pik using ${mydata}/SED_phf.dta //Data from 01c
drop _merge

*Save this as a tempfile, then bring in survey data.
tempfile icfmerge
save `icfmerge'

use pik sex race2 citiz birthpl birthyr using  ${mydata}/SED_2001_2017.dta, clear
drop if missing(pik)

gduplicates report pik

destring birthpl, replace

gen us_born=(birthpl<100)

gen us_citiz=(citiz=="0"|citiz=="1"|citiz=="U"|citiz=="P"|citiz=="2"|citiz=="A")

gcollapse (firstnm) sex race2 birthyr us_born us_citiz, by(pik)

merge 1:m pik using `icfmerge'


*Fill in missing values with SED values and create aggregate race categories

replace sex=1 if missing(sex) & sex_icf=="M"

replace sex=2 if missing(sex) & sex_icf=="F"

tab sex, m

*Drop SED race variables (using combined race/hispanic variable)
*Remove non-US citizen from other groups
drop hispanic white black amerind asian hawaiian raceoth

*Replace missing race/ethnicity
gen hispanic=(race2<=7)
replace hispanic=1 if ethnicity=="H" & race2>=15
replace hispanic=0 if us_citiz==0

gen white=(race2==5|race2==12|race2==19)
replace white=1 if race_icf=="1" & (race2==7|race2==14|race2==21|race2==.)
replace white=0 if us_citiz==0

gen black=(race2==3|race2==10|race2==17)
replace black=1 if race_icf=="2" & (race2==7|race2==14|race2==21|race2==.)
replace black=0 if us_citiz==0

gen aian=(race2==1|race2==8|race2==15)
replace aian=1 if race_icf=="3" & (race2==7|race2==14|race2==21|race2==.)
replace aian=0 if us_citiz==0

gen asian=(race2==2|race2==9|race2==16)
replace asian=1 if race_icf=="4" & (race2==7|race2==14|race2==21|race2==.)
replace asian=0 if us_citiz==0

gen nhpi=(race2==4|race2==11|race2==18)
replace nhpi=1 if race_icf=="5" & (race2==7|race2==14|race2==21|race2==.)
replace nhpi=0 if us_citiz==0

gen twoplus=(race2==6|race2==13|race2==20)
replace twoplus=1 if race_icf=="7" & (race2==7|race2==14|race2==21|race2==.)
replace twoplus=0 if us_citiz==0

gen race_harm=1 if white==1
replace race_harm=2 if black==1
replace race_harm=3 if aian==1
replace race_harm=4 if asian==1
replace race_harm=5 if nhpi==1
replace race_harm=7 if twoplus==1
replace race_harm=8 if us_citiz==0

tab race_icf race_harm, m

tab ethnicity hispanic, m

#delimit ;
*Aggregated race variable;
gen race_agg=1*(hispanic==1 & us_citiz==1)+
	2*(aian==1 & hispanic!=1 & us_citiz==1)+
	3*(asian==1 & hispanic!=1 & us_citiz==1)+
	4*(black==1 & hispanic!=1 & us_citiz==1)+
	5*(nhpi==1 & hispanic!=1 & us_citiz==1)+
	6*(white==1 & hispanic!=1 & us_citiz==1)+
	7*(twoplus==1 & hispanic!=1 & us_citiz==1)+
	8*(us_citiz==0);
replace race_agg=9 if race_agg==.;

label define racelbl 
1 "Hispanic"
2 "AIAN"
3 "Asian"
4 "Black"
5 "NHPI"
6 "White"
7 "Two or More"
8 "Non-Citizen"
9 "Other/Not Reported", replace;
label values race_agg racelbl;

gen race_agg2=1 if (hispanic==1 & us_citiz==1);
replace race_agg2=3 if (asian==1 & hispanic!=1 & us_citiz==1);
replace race_agg2=4 if (black==1 & hispanic!=1 & us_citiz==1);
replace race_agg2=6 if (white==1 & hispanic!=1 & us_citiz==1);
replace race_agg2=8 if (us_citiz==0);
replace race_agg2=9 if race_agg==.;
	
label define racelbl2
1 "Hispanic"
3 "Asian"
4 "Black"
6 "White"
8 "Non-Citizen"
9 "Other/Not Reported", replace;
label values race_agg2 racelbl2;

#delimit cr



save ${mydata}/icf_phf_sed_merge.dta, replace



