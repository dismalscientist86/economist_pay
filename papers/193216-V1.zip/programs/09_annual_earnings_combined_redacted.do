/*************************
Program name: 04b_annual_earnings_combined.do
Created by: Dani Sandler
Created on: April 6, 2021
Purpose: Create an annual earnings series, combining W2 & LEHD earnings
Modifications: 
      7/14/2021 - Keep full NAICS code to break out more detailed industries
      1/27/2023 - DHS - Use 2021 LEHD data
***************************/
 
*Master setup program
do 00_master_SED_LEHD.do


use ${mydata}/SED_w2_earnings2020.dta, clear
*Keep missing government agencies
#delimit ;
*Federal Reserve, World Bank, Department of Defense, 
  IMF, US Air Force, US House of Representatives, 
  US Department of State, Department of Defense (second EIN)
  CIA, Dept of Agriculture*, Dept of Interior*
  *Starred agencies are joint payroll. Some agencies may be included in OPM, others not. Including
  them here may end up double-counting salaries. Need to think about how to address this. Exclude
  a lot of observations (>1000 economists*years) if we don't add them in;

keep if inlist(ein, "XXXXXXXXX");
#delimit cr

*Set NAICS code to 92 
gen naics2017_2digit="92"


rename wage_tip e

tempfile w2_gov
save `w2_gov', replace

*Similar exercise for Massachusetts universities (prior to 2010 when MA joined LEHD)

use ${mydata}/SED_w2_earnings2020.dta, clear
*Keep missing universities pre-2010
#delimit ;
*Harvard, MIT, Boston University, NBER, Brandeis, Tufts,
  Bentley University, Boston Fed, Williams College, Northeastern
  Amherst College, Clark University;
keep if inlist(ein, "XXXXXXXXX");
#delimit cr

keep if year<2010

*Set NAICS code to 61 
gen naics2017_2digit="61"
*Change Boston Fed to 92
replace naics2017_2digit="92" if ein=="XXXXXXXXX"

rename wage_tip e

tempfile w2_edu
save `w2_edu', replace

*Bring in RePEC instiution ranks
insheet using ${mydata}/Repec_department_rankings.csv, clear
rename ipeds_num phdinst
rename repecrank repec_rank
drop if missing(phdinst)
sort phdinst repec_rank
drop if phdinst==phdinst[_n-1]
*Use institution name to label Repec ranks
local N=_N
forvalues n=1/`N'{
label define ranklab `=repec_rank[`n']' "`=name[`n']'", modify
}
label values repec_rank ranklab
keep repec_rank phdinst
tempfile repec
save `repec', replace


use ${mydata}/SED_annualearn2021.dta, clear

*Append the W2 data
append using `w2_gov'
append using `w2_edu'

*Fill in NAICS for W2 observations
*(Copied from /mcent002/00.02.add_ein_naics.sas on 7-14-2021. Should check for updates)
replace mode_naics2017fnl_emp="XXXXXX" if ein=="XXXXXXXXX"      


*Merge on RePEC institution rankings
merge m:1 phdinst using `repec', gen(repec_merge)
drop if repec_merge==2
drop repec_merge

*Create bins of RePEC rank
gen repec_bin=1 if repec_rank<=5
replace repec_bin=2 if repec_rank>5 & repec_rank<=20
replace repec_bin=3 if repec_rank>20 & repec_rank<=50
replace repec_bin=4 if repec_rank>50 & repec_rank<=100
replace repec_bin=5 if repec_rank==.

label define repeclbl 1 "RePEC Rank Top 5" 2 "RePEC Rank 6 to 20" 3 "RePEC Rank 21 to 50" 4 "RePEC Rank 50 to 100" 5 "RePEC Rank 100+"
label values repec_bin repeclbl

*Fix year
tab year, m
replace year=phdfy+years_since if missing(year)


save ${mydata}/SED_annualearn_combo2021.dta, replace
