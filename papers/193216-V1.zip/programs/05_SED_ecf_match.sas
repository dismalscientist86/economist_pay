/***************************************************
*This program reads in the LEHD 2018 interleave file because
*Stata's import sas command cannot read it.
*Created by: Dani Sandler
*Created on: November 4, 2020
*Modifications:
  11/4/2020 - DHS - Modified from 02d_economist_ecf_match.sas
  1/25/2023 - DHS - Updated to use 2021 Interleave
            Added proc datasets delete to bottom of program

***************************************************/


proc contents data=inter.ecf_interleave_sein_t13;
run;

proc import out=mydata.SED_sein 
datafile="SED_sein.dta"
replace;
run;

proc sort data=mydata.SED_sein
    out=mydata.SED_sein;
    by sein qtime;
run;

proc sort data=inter.ecf_interleave_sein_t13
    out=mydata.ecf_interleave_sein_t13;
    by sein qtime;
run;

data mydata.ecf_SED_match;
  merge mydata.ecf_interleave_sein_t13 (in=ecf)
	mydata.SED_sein (in=econ);
	by sein qtime;
	if econ=1;
run;

proc export data=mydata.ecf_SED_match
  outfile="ecf_SED_match.dta"
  dbms=stata replace;
run;

proc datasets library=mydata;
  delete ecf_interleave_sein_t13;
run;
